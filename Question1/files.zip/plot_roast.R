
# Average rating by roast level, to show which roasts drink best:
plot_roast <- function(df){

    df %>%
        group_by(roast) %>%                                            # group by roast strength
        summarise(Rating = mean(Rating, na.rm = TRUE), n = n()) %>%    # mean rating and count per roast
        filter(n >= 5) %>%                                             # drop tiny groups
        mutate(roast = fct_reorder(roast, Rating)) %>%                 # order bars by rating
        ggplot(aes(roast, Rating)) +
        geom_col(fill = "#7B4B2A") +                                   # espresso-brown bars
        geom_text(aes(label = round(Rating, 1)), hjust = -0.15, size = 3) +  # rating label on each bar
        coord_flip(ylim = c(88, 95)) +                                 # flip for readability
        theme_minimal() +
        labs(x = "", y = "Average rating", title = "Lighter roasts score highest")
}
