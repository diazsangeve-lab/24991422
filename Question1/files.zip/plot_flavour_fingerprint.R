
# What sets the very best coffees apart: share of reviews mentioning each flavour
# word, comparing the top coffees (rating 95+) against the whole catalogue:
plot_flavour_fingerprint <- function(df, words, top_cut = 95){

    share <- function(sub) map_dbl(words, ~mean(str_detect(str_to_lower(sub$desc_all), .x)))

    tibble(Word = words,                                               # each flavour word
           Top  = share(df %>% filter(Rating >= top_cut)),             # share among the best coffees
           All  = share(df)) %>%                                       # share across all coffees
        mutate(Gap = Top - All) %>%                                    # how much more the best use it
        arrange(desc(Gap)) %>% slice_head(n = 8) %>%                   # the most distinguishing words
        pivot_longer(c(Top, All), names_to = "Set", values_to = "Share") %>%
        ggplot(aes(reorder(Word, Share), Share, fill = Set)) +
        geom_col(position = "dodge") +                                 # top vs all, side by side
        coord_flip() +
        scale_y_continuous(labels = scales::percent) +
        scale_fill_manual(values = c(Top = "#C75B39", All = "#D9C2A6")) +
        theme_minimal() +
        labs(x = "", y = "Reviews mentioning the word",
             title = "The best coffees are juicy, syrupy, floral and bright")
}
