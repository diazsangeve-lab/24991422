
# The suppliers worth stocking: mean rating against mean cost, for roasters with a
# real range on offer. Labelled so we can pick value champions and premium names:
plot_supplier_leaderboard <- function(df, min_coffees = 10){

    df %>%
        group_by(roaster) %>%                                          # group by supplier
        summarise(Rating = mean(Rating, na.rm = TRUE),                 # mean rating
                  Cost   = mean(Cost_Per_100g, na.rm = TRUE),          # mean cost
                  n      = n()) %>%                                     # how many coffees they offer
        filter(n >= min_coffees, Rating >= 93) %>%                     # well-stocked, high-scoring suppliers
        ggplot(aes(Cost, Rating, size = n)) +
        geom_point(colour = "#7B4B2A", alpha = 0.8) +                  # espresso bubbles
        ggrepel::geom_text_repel(aes(label = roaster), size = 2.6, max.overlaps = 15) +
        scale_size(range = c(3, 11), guide = "none") +
        theme_minimal() +
        labs(x = "Average cost per 100g (USD)", y = "Average rating",
             title = "Suppliers worth stocking, by quality and price")
}
